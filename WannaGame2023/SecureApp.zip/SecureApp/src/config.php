<?php

require 'database.php';

$db_connect = new DB();
$conn = $db_connect->getInstance();
?>